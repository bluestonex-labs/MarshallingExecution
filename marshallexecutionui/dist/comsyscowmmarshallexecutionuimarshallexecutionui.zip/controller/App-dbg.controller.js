sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("com.sysco.wm.marshallexecutionui.marshallexecutionui.controller.App", {
      onInit() {
      }
  });
});